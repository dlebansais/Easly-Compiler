﻿namespace Easly
{
    public class DateAndTime
    {
        #region Properties
        public virtual string ToUtcDateAndTime { get; }
        #endregion
    }
}
